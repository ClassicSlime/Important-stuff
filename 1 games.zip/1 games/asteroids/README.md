HTML5-Asteroids
===============

Pure Javascript Asteroids, based on http://dougmcinnes.com/2010/05/12/html-5-asteroids/ 
Source https://github.com/dmcinnes/HTML5-Asteroids
