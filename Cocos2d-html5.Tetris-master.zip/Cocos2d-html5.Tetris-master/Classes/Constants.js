//  Created by Ken<congbach@congbach.com> on 22/6/12.

var INVALID 		= -1;
var UNINITIALIZED 	= -1;
var INT_MAX			= 9007199254740992;
var INT_MIN			= -9007199254740992;