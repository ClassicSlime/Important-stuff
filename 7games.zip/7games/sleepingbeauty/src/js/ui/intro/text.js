let node = document.createElement("div");
node.classList.add("text");
node.innerHTML = 
`Into a profound slumber she sank, surrounded only by dense brambles, thorns and roses.
Many adventurers tried to find and rescue her, but none came back...
<br/><br/><span>Hit [Enter] to start the game</span>`;

export function getNode() {
	return node;
}
