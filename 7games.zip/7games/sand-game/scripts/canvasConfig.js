const __max_width=560,__max_height=480,width=Math.min(560,Math.max(screen.width-6,1)),height=Math.min(480,Math.max(screen.height-200,100)),MAX_FPS=120,DEFAULT_FPS=60,MAX_NUM_PARTICLES=1e3;
